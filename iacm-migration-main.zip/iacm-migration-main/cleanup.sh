#!/bin/bash
rm -rf .terraform terraform.tfstate terraform.tfstate.backup .terraform.lock.hcl out/state out/.terraform out/terraform.tfstate out/terraform.tfstate.backup out/.terraform.lock.hcl